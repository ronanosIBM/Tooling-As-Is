package com.ibm.ima.pluglets.samples.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.ui.model.BaseWorkbenchContentProvider;

import com.ibm.datatools.core.internal.ui.util.EMFUtilities;
import com.ibm.datatools.internal.core.resource.DataModelResource;
import com.ibm.datatools.logical.internal.ui.explorer.providers.content.node.LogicalDatabaseModel;
import com.ibm.datatools.project.internal.ui.explorer.providers.content.node.DatabaseDesignProject;
import com.ibm.datatools.project.ui.node.IModel;
import com.ibm.db.models.logical.Entity;
import com.ibm.db.models.logical.Package;

public class LogicalDataModelContentProvider extends BaseWorkbenchContentProvider {

	public static final String IDA_NATURE = "com.ibm.datatools.core.ui.DatabaseDesignNature";
	
	public static final int DEPTH_MODEL = 0;
	public static final int DEPTH_PACKAGE = 1;
	public static final int DEPTH_ENTITY = 2;
	public static final int DEPTH_ATTRIBUTE = 3;
	
	private int depth;
	/**
	 * Allocates a new LogicalDataModelContentProvider with a sepcified content depth 
	 * @param depth one of DEPTH_MODEL, DEPTH_PACKAGE, DEPTH_ENTITY, DEPTH ATTRIBUTE
	 */
	public LogicalDataModelContentProvider(int depth) {
		this.depth = depth;
	}
	
	/**
	 * Allocates a new LogicalDataModelContentProvider with a default content depth of
	 * Entity
	 */
	public LogicalDataModelContentProvider() {
		this(DEPTH_ENTITY);
	}
	
	/*
	 * Used to compute top level tree elements
	 * @see org.eclipse.ui.model.BaseWorkbenchContentProvider#getElements(java.lang.Object)
	 */
	@Override
	public Object[] getElements(Object element) {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IProject[] projects = root.getProjects();
		List<Object> openDataProjects = new ArrayList<Object>();
		for (int i = 0; i < projects.length; i++) {
			IProject project = projects[i];
			/* Check if project is open, and an IDA data design project */
			try {
				if (project.isOpen() && project.hasNature(IDA_NATURE)) {
					DatabaseDesignProject projectNode = new DatabaseDesignProject(project);
					if (getChildren(projectNode).length > 0) {
						openDataProjects.add(projectNode);
					}
				}
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return openDataProjects.toArray();
	}
	
	@Override
	public Object[] getChildren(Object element) {
		List<Object> validChildren = new ArrayList<Object>();
		if (element instanceof DatabaseDesignProject) {
			DatabaseDesignProject projectNode = (DatabaseDesignProject) element;
			IProject project = projectNode.getProject();
			List<IFile> projectFiles = getFilesRecursively(project);
			Iterator<IFile> projectFilesIter = projectFiles.iterator();
			while (projectFilesIter.hasNext()) {
				IFile nextFile = projectFilesIter.next();
				if (nextFile.getFileExtension().equals("ldm")) {
					Resource emfResource = EMFUtilities.getEMFResource(nextFile);
					if (emfResource != null && 
							emfResource.isLoaded() && emfResource instanceof DataModelResource) {
						LogicalDatabaseModel modelNode = new LogicalDatabaseModel();
						modelNode.setResource(nextFile);
						validChildren.add(modelNode);
					}
				}
			}
		}
		else if (element instanceof IModel) {
			IModel model = (IModel) element;
			return model.getRoots();
		}
		else if (element instanceof Package && depth > DEPTH_MODEL) {
			Package pkg = (Package) element;
			validChildren.addAll(pkg.getChildren());
			if (depth > DEPTH_PACKAGE) {
				Iterator contentsIter = pkg.getContents().iterator();
				while (contentsIter.hasNext()) {
					Object nxtObject = contentsIter.next();
					if (nxtObject instanceof Entity) {
						validChildren.add((Entity) nxtObject);
					}
				}
			}
		}
		else if (element instanceof Entity && depth > DEPTH_ENTITY) {
			Entity entity = (Entity) element;
			validChildren.addAll(entity.getAttributes());
		}
		return validChildren.toArray();
	}
	
	private List<IFile> getFilesRecursively(IResource resource) {
		List<IFile> files = new LinkedList<IFile>();
		if (resource instanceof IContainer) {
			try {
				IResource[] members = ((IContainer) resource).members();
				for (int i = 0; i < members.length; i++) {
					IResource childRes = members[i];
					if (childRes instanceof IFile) {
						files.add((IFile) childRes);
					}
					else if (childRes instanceof IContainer) {
						files.addAll(getFilesRecursively(childRes));
					}
				}
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return files;
	}
}
