package com.ibm.ima.pluglets.samples.data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.datatools.modelbase.sql.schema.SQLObject;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ElementTreeSelectionDialog;

import com.ibm.datatools.core.DataToolsPlugin;
import com.ibm.datatools.pluglets.ui.DataPluglet;
import com.ibm.datatools.pluglets.ui.DataPlugletTaskGroup;
import com.ibm.db.models.logical.Attribute;
import com.ibm.db.models.logical.Entity;
import com.ibm.db.models.logical.ForeignKey;
import com.ibm.db.models.logical.Generalization;
import com.ibm.db.models.logical.GeneralizationSet;
import com.ibm.db.models.logical.LogicalDataModelFactory;
import com.ibm.db.models.logical.Package;
import com.ibm.db.models.logical.PrimaryKey;
import com.ibm.db.models.logical.Relationship;
import com.ibm.db.models.logical.RelationshipEnd;
import com.ibm.xtools.pluglets.Pluglet;

public class CloneSelectedEntities extends Pluglet implements DataPluglet {
	
	// TODO: choose task groups under which this pluglet should appear in the 'Run Pluglet' menu
	private static final DataPlugletTaskGroup[] taskGroups = 
		new DataPlugletTaskGroup[] {DataPlugletTaskGroup.CUSTOM_TASKS};
	
	private boolean cloneAnnotations = true;
	private boolean cloneNonPersistentElements = false;
	private boolean createTraceability = false;
	private boolean cloneGeneralizations = true;
	private boolean cloneRelationships = true;
	private boolean includeInheritedPKAttributes = true;
	
	private Map<SQLObject, SQLObject> sourceToTargetMap;
	
	@Override
	public String getName() {
		// TODO: choose name for this pluglet to appear in the 'Run Pluglet' menu
		return "Clone Selected Entities";
	}

	/* (non-Javadoc)
	 * @see com.ibm.datatools.pluglets.ui.DataPluglet#getTaskGroups()
	 */
	public DataPlugletTaskGroup[] getTaskGroups() {
		return taskGroups;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.datatools.pluglets.ui.DataPluglet#isValidSelection(ISelection)
	 */
	public boolean isValidSelection(ISelection selection) {
		if (selection instanceof StructuredSelection) {
			List<?> selectionList = ((StructuredSelection) selection).toList();
			for (Object object : selectionList) {
				
				if (!(object instanceof Entity)) {
					return false;		
				}
			}
			// all selected objects were SQLObjects
			return true;
		}
		// we could not verify the workspace selection
		return false;
	}
		
	/**
	 * @return the current workspace selection
	 */
	private ISelection getWorkspaceSelection() {
		return PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getSelectionService().getSelection();
	}

	/**
	 * The pluglet's main method will be invoked when the pluglet is run.
	 * 
	 * @param args
	 */
	public void plugletmain(String[] args) {
		
		// get the workspace selection
		ISelection workspaceSelection = getWorkspaceSelection();
    	
		// verify this pluglet can run on the selected objects
		if (!isValidSelection(workspaceSelection)) {
			inform("Current workspace selection is not valid for pluglet \"CloneSelectedEntities\"."); //$NON-NLS-1$
		}
		Shell shell = null;
        IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
        if (window != null) {
           shell = window.getShell();
        }
        
        ITreeContentProvider contentProvider = new LogicalDataModelContentProvider(
        		LogicalDataModelContentProvider.DEPTH_PACKAGE);
        ILabelProvider labelProvider = new LogicalDataModelLabelProvider();
        ElementTreeSelectionDialog etsd = new ElementTreeSelectionDialog(
        		shell, labelProvider, contentProvider);
        etsd.setAllowMultiple(false);
        etsd.setInput(contentProvider.getElements(null));
        etsd.setTitle("Select the target package for cloning");
        if (etsd.open() == ElementTreeSelectionDialog.OK) {
        	Object[] result = etsd.getResult();
        	if (result.length == 1 && result[0] instanceof Package) {
        		if (workspaceSelection instanceof StructuredSelection) {
        			StructuredSelection selection = (StructuredSelection) workspaceSelection;
        			List<Entity> entities = new LinkedList<Entity>();
        			Object[] selectedObjects = selection.toArray();
        			for (int i = 0; i < selectedObjects.length; i ++) {
        				if (selectedObjects[i] instanceof Entity) {
        					entities.add((Entity) selectedObjects[i]);
        				}
        			}
            		cloneEntities(entities, (Package) result[0]);
        		}
        	}
        	else  {
        		error("Must select a package as target for cloning", "Invalid Target");
        	}
        }
	}
	
	private void cloneEntities(final List<Entity> entities, final Package targetPackage) {
		TransactionalEditingDomain editingDomain = 
				DataToolsPlugin.getDefault().getEditingDomain();
		editingDomain.getCommandStack().execute(new RecordingCommand(editingDomain) {

			@Override
			protected void doExecute() {
				Iterator<Entity> entitiesIter = entities.iterator();
				sourceToTargetMap = new HashMap<SQLObject, SQLObject>();
				while (entitiesIter.hasNext()) {
					Entity sourceEntity = entitiesIter.next();
					Entity targetEntity = null;
					if (sourceEntity.isPersistent() || cloneNonPersistentElements) {
						targetEntity = cloneEntity(sourceEntity, targetPackage);
					}
					if (targetEntity != null) {
						sourceToTargetMap.put(sourceEntity, targetEntity);
					}
				}
				if (cloneGeneralizations) {
					cloneGeneralizations();
				}
				if (cloneRelationships) {
					cloneRelationships();
				}
			}		
		});
	}
	
	/*
	 * Clone generalizations for the source entities where both supertype and
	 * subtype are present in the selection for cloning
	 */
	private void cloneGeneralizations( ) {
		Set<Entity> srcEntities = new HashSet<Entity>();
		Iterator<SQLObject> sourceObjects = sourceToTargetMap.keySet().iterator();
		while (sourceObjects.hasNext()) {
			SQLObject sqlObject = sourceObjects.next();
			if (sqlObject instanceof Entity) {
				srcEntities.add((Entity) sqlObject);
			}
		}
		Iterator<Entity> srcEntitiesIter = srcEntities.iterator();
		while (srcEntitiesIter.hasNext()) {
			/* Work from supertype down to correctly replicate gen sets */
			Entity srcSupertype = srcEntitiesIter.next();
			Entity tgtSupertype = (Entity) sourceToTargetMap.get(srcSupertype);
			Iterator srcSupertypeGenSets = srcSupertype.getGeneralizationSets().iterator();
			while (srcSupertypeGenSets.hasNext()) {
				GeneralizationSet srcSupertypeGenSet = 
						(GeneralizationSet) srcSupertypeGenSets.next();
				/* Only create a gen set in the target entity if 
				 * there are generalizations to add */
				List<Entity> subtypesInSelection = new LinkedList<Entity>();
				Iterator srcSpecializations = 
						srcSupertypeGenSet.getGeneralizations().iterator();
				GeneralizationSet tgtSupertypeGenSet = null;
				while (srcSpecializations.hasNext()) {
					Generalization srcSpecialization = 
							(Generalization) srcSpecializations.next();
					if (sourceToTargetMap.keySet().contains(
							srcSpecialization.getSubtype())) {
						/* If gen set not yet cloned, create one */
						if (tgtSupertypeGenSet == null) {
							tgtSupertypeGenSet = LogicalDataModelFactory.eINSTANCE.
									createGeneralizationSet();
							tgtSupertypeGenSet.setEntity(tgtSupertype);
							tgtSupertypeGenSet.setDescription(srcSupertypeGenSet.getDescription());
							tgtSupertypeGenSet.setName(srcSupertypeGenSet.getName());
							if (srcSupertype.getDefaultSet() == srcSupertypeGenSet) {
								tgtSupertype.setDefaultSet(tgtSupertypeGenSet);
							}
							tgtSupertypeGenSet.setPhysicalOption(srcSupertypeGenSet.getPhysicalOption());
							tgtSupertype.getGeneralizationSets().add(tgtSupertypeGenSet);
						}
						/* Now clone the generalization
						 */
						Generalization tgtSpecialization = 
								LogicalDataModelFactory.eINSTANCE.createGeneralization();
						tgtSpecialization.setSupertype(tgtSupertype);
						tgtSpecialization.setSubtype((Entity)
								sourceToTargetMap.get(srcSpecialization.getSubtype()));
						tgtSpecialization.setName(srcSpecialization.getName());
						tgtSpecialization.setDescription(srcSpecialization.getDescription());
						tgtSpecialization.setGeneralizationSet(tgtSupertypeGenSet);
						tgtSupertype.getSpecializations().add(tgtSpecialization);
						tgtSupertypeGenSet.getGeneralizations().add(tgtSpecialization);
						ForeignKey tgtForeignKey = cloneForeignKey(srcSpecialization.getForeignKey());
						tgtSpecialization.setForeignKey(tgtForeignKey);
						tgtForeignKey.setGeneralization(tgtSpecialization);
						tgtSpecialization.getSubtype().getForeignKeys().add(tgtForeignKey);
						tgtSupertypeGenSet.setDefiningAttribute((Attribute)
								sourceToTargetMap.get(srcSupertypeGenSet.getDefiningAttribute()));
						tgtSpecialization.setAlternateKey(tgtSupertype.getPrimaryKey());
					}
				}
			}
		}
	}
	
	/*
	 * Clone Relationships between selected Entities
	 */
	private void cloneRelationships( ) {
		Set<Entity> srcEntities = new HashSet<Entity>();
		Iterator<SQLObject> sourceObjects = sourceToTargetMap.keySet().iterator();
		while (sourceObjects.hasNext()) {
			SQLObject sqlObject = sourceObjects.next();
			if (sqlObject instanceof Entity) {
				srcEntities.add((Entity) sqlObject);
			}
		}
		Iterator<Entity> srcEntitiesIter = srcEntities.iterator();
		while (srcEntitiesIter.hasNext()) {
			/* Work from child end entities */
			Entity srcChildEntity = srcEntitiesIter.next();
			Entity tgtChildEntity = (Entity) sourceToTargetMap.get(srcChildEntity);
			Iterator srcChildRelationships = 
					srcChildEntity.getRelationships().iterator();
			while (srcChildRelationships.hasNext()) {
				Relationship srcRlship = (Relationship) srcChildRelationships.next();
				RelationshipEnd srcRlshipChildEnd = srcRlship.getChildEnd();
				/* Check that srcChildEntity is the child in this relationship */
				if (srcRlshipChildEnd != null && 
						srcRlshipChildEnd.getEntity() == srcChildEntity) {
					/* Get the parent end and confirm the parent entity is cloned */
					RelationshipEnd srcRlshipParentEnd = srcRlship.getParentEnd();
					if (srcRlshipParentEnd != null && 
							sourceToTargetMap.containsKey(srcRlshipParentEnd.getEntity())) {
						/* Can clone relationship */
						Relationship tgtRlship = cloneRelationship(srcRlship);
					}
				}
			}
		}
	}
	
	private Relationship cloneRelationship(Relationship srcRlship) {
		RelationshipEnd srcChildRelEnd = srcRlship.getChildEnd();
		RelationshipEnd srcParentRelEnd = srcRlship.getParentEnd();
		Entity srcChildEntity = srcChildRelEnd.getEntity();
		Entity srcParentEntity = srcParentRelEnd.getEntity();
		ForeignKey srcChildFK = (ForeignKey) srcChildRelEnd.getKey();
		PrimaryKey srcParentPK = (PrimaryKey) srcParentRelEnd.getKey();
		
		/* Clone the Relationship */
		Relationship tgtRlship = LogicalDataModelFactory.eINSTANCE.createRelationship();
		tgtRlship.setName(srcRlship.getName());
		tgtRlship.setDescription(srcRlship.getDescription());
		cloneAnnotations(srcRlship, tgtRlship);
		
		/* Clone the RelationshipEnds */
		RelationshipEnd tgtChildRelEnd = cloneRelationshipEnd(srcChildRelEnd);
		RelationshipEnd tgtParentRelEnd = cloneRelationshipEnd(srcParentRelEnd);

		/* Clone the ForeignKey */
		ForeignKey tgtChildFK = cloneForeignKey(srcChildFK);
		
		/* Connect the objects */
		Entity tgtChildEntity = (Entity) sourceToTargetMap.get(srcChildEntity);
		Entity tgtParentEntity = (Entity) sourceToTargetMap.get(srcParentEntity);
		tgtChildRelEnd.setEntity(tgtChildEntity);
		tgtChildRelEnd.setRelationship(tgtRlship);
		tgtChildRelEnd.setKey(tgtChildFK);
		tgtChildEntity.getRelationshipEnds().add(tgtChildRelEnd);
		tgtChildEntity.getRelationships().add(tgtRlship);
		
		tgtParentRelEnd.setEntity(tgtParentEntity);
		tgtParentRelEnd.setKey(tgtParentEntity.getPrimaryKey());
		tgtParentRelEnd.setRelationship(tgtRlship);
		tgtParentEntity.getRelationshipEnds().add(tgtParentRelEnd);
		
		return tgtRlship;
	}
	
	private RelationshipEnd cloneRelationshipEnd(RelationshipEnd srcRelEnd) {
		RelationshipEnd tgtRelEnd = 
				LogicalDataModelFactory.eINSTANCE.createRelationshipEnd();
		tgtRelEnd.setName(srcRelEnd.getName());
		tgtRelEnd.setDescription(srcRelEnd.getDescription());
		tgtRelEnd.setVerbPhrase(srcRelEnd.getVerbPhrase());
		tgtRelEnd.setCardinality(srcRelEnd.getCardinality());
		tgtRelEnd.setNavigable(srcRelEnd.isNavigable());
		return tgtRelEnd;
	}
	
	/*
	 * Clones a Foreign Key from source to target
	 */
	private ForeignKey cloneForeignKey(ForeignKey srcFK) {
		Entity srcEntity = srcFK.getEntity();
		Entity tgtEntity = (Entity) sourceToTargetMap.get(srcEntity);
		ForeignKey tgtFK = LogicalDataModelFactory.eINSTANCE.createForeignKey();
		tgtFK.setName(srcFK.getName());
		tgtFK.setAbbreviation(srcFK.getAbbreviation());
		tgtFK.setDescription(srcFK.getDescription());
		tgtFK.setEntity(tgtEntity);
		/* Clone the attributes in the FK, where not already contained */
		Iterator srcFKAttributes = srcFK.getAttributes().iterator();
		while (srcFKAttributes.hasNext()) {
			Attribute srcFKAttribute = (Attribute) srcFKAttributes.next();
			if (cloneNonPersistentElements || srcFKAttribute.isPersistent()) {
				Attribute tgtFKAttribute = sourceToTargetMap.containsKey(srcFKAttribute) ? 
						(Attribute) sourceToTargetMap.get(srcFKAttribute) : 
							cloneAttribute(srcFKAttribute, tgtEntity);
				tgtFK.getAttributes().add(tgtFKAttribute);
				/* Check in case FK should make up part of PK */
				if (srcFKAttribute.isPartOfPrimaryKey()) {
					PrimaryKey tgtPK = tgtEntity.getPrimaryKey();
					/* Might not yet exist e.g. for generalizations */
					if (tgtPK == null) {
						tgtPK = clonePK(srcEntity, tgtEntity);
					}
					tgtPK.getAttributes().add(tgtFKAttribute);
				}
			}
		}
		sourceToTargetMap.put(srcFK, tgtFK);
		cloneAnnotations(srcFK, tgtFK);
		return tgtFK;
	}
	
	private Entity cloneEntity(Entity sourceEntity, Package targetPackage) {
		/* Clone basics */
		Entity targetEntity = LogicalDataModelFactory.eINSTANCE.createEntity();
		targetEntity.setName(sourceEntity.getName());
		targetEntity.setDescription(sourceEntity.getDescription());
		targetEntity.setAbbreviation(sourceEntity.getAbbreviation());
		targetEntity.setPackage(targetPackage);
		
		/* Clone non-key attributes */
		Iterator attrsIter = sourceEntity.getAttributes().iterator();
		while (attrsIter.hasNext()) {
			Object nxtObj = attrsIter.next();
			if (nxtObj instanceof Attribute) {
				Attribute srcAttr = (Attribute) nxtObj;
				/* Attributes are to be cloned by default iff
				 * 1. They have not already been cloned
				 * 2. They are not part of a Foreign Key (may be included later if in scope)
				 * 3. They are part of an FK but also part of an inherited PK, 
				 *    and includeInheritedPKatributes is set
				 * 4. They are part of a PK
				 * 5. They are persistent or cloneNonPersistentElements is set
				 */
				if (!sourceToTargetMap.containsKey(srcAttr) && 
						(!srcAttr.isPartOfForeignKey() || isInheritedPKAttribute(srcAttr))) {
					/* persistence check */
					if (srcAttr.isPersistent() || cloneNonPersistentElements) {
						Attribute tgtAttr = cloneAttribute(srcAttr, targetEntity);
						if (srcAttr.isPartOfPrimaryKey()) {
							PrimaryKey targetPrimaryKey = targetEntity.getPrimaryKey();
							if (targetPrimaryKey == null) {
								targetPrimaryKey = clonePK(sourceEntity, targetEntity);
							}
							targetPrimaryKey.getAttributes().add(tgtAttr);
						}
					}
				}
			}
		}
		if (cloneAnnotations) {
			cloneAnnotations(sourceEntity, targetEntity);
		}
		return targetEntity;
	}
	
	private boolean isInheritedPKAttribute(Attribute attribute) {
		if (attribute.isPartOfForeignKey() && attribute.isPartOfPrimaryKey()) {
			Entity entity = attribute.getEntity();
			Iterator gensIter = entity.getGeneralizations().iterator();
			while (gensIter.hasNext()) {
				Generalization gen = (Generalization) gensIter.next();
				if (gen.getForeignKey() != null && 
						gen.getForeignKey().getAttributes().contains(attribute)) {
					return true;
				}
			}
		}
		return false;
	}
	
	private PrimaryKey clonePK(Entity sourceEntity, Entity targetEntity) {
		PrimaryKey sourcePrimaryKey = sourceEntity.getPrimaryKey();
		PrimaryKey targetPrimaryKey = 
				LogicalDataModelFactory.eINSTANCE.createPrimaryKey();
		targetPrimaryKey.setName(sourcePrimaryKey.getName());
		targetPrimaryKey.setEntity(targetEntity);
		targetPrimaryKey.setDescription(
				sourcePrimaryKey.getDescription());
		targetPrimaryKey.setPersistent(
				sourcePrimaryKey.isPersistent());
		targetEntity.getKeys().add(targetPrimaryKey);
		if (cloneAnnotations) {
			cloneAnnotations(
					sourcePrimaryKey, targetPrimaryKey);
		}
		return targetPrimaryKey;
	}
	
	private Attribute cloneAttribute(Attribute sourceAttribute, Entity targetEntity) {
		Attribute targetAttribute = LogicalDataModelFactory.eINSTANCE.createAttribute();
		targetAttribute.setName(sourceAttribute.getName());
		targetAttribute.setDescription(sourceAttribute.getDescription());
		targetAttribute.setAbbreviation(sourceAttribute.getAbbreviation());
		targetAttribute.setDataType(sourceAttribute.getDataType());
		targetAttribute.setEntity(targetEntity);
		targetAttribute.setPersistent(sourceAttribute.isPersistent());
		if (cloneAnnotations) {
			cloneAnnotations(sourceAttribute, targetAttribute);
		}
		sourceToTargetMap.put(sourceAttribute, targetAttribute);
		return targetAttribute;
	}
	/*
	 * Clone the EAnnotations (IGC mappings, UDPs etc from source to target
	 */
	private void cloneAnnotations(SQLObject sourceObject, SQLObject targetObject) {
		Iterator<EAnnotation> annotsIter = sourceObject.getEAnnotations().iterator();
		while (annotsIter.hasNext()) {
			EAnnotation srcAnnot = annotsIter.next();
			String srcSource = srcAnnot.getSource();
			EAnnotation tgtAnnot = targetObject.getEAnnotation(srcSource);
			if (tgtAnnot == null) {
				tgtAnnot = targetObject.addEAnnotation(srcSource);
			}
			/* go through source annotation details */
			Iterator<Entry<String, String>> srcDetailsIter = 
					srcAnnot.getDetails().iterator();
			while (srcDetailsIter.hasNext()) {
				Entry<String, String> srcEntry = srcDetailsIter.next();
				tgtAnnot.getDetails().put(srcEntry.getKey(), srcEntry.getValue());
			}
		}
	}
}
