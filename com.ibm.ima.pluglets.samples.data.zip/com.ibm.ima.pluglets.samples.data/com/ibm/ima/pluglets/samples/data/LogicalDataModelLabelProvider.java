package com.ibm.ima.pluglets.samples.data;

import org.eclipse.datatools.connectivity.sqm.core.internal.ui.services.DataToolsUIServiceManager;
import org.eclipse.datatools.connectivity.sqm.core.ui.explorer.providers.content.virtual.VirtualNode;
import org.eclipse.datatools.modelbase.sql.schema.SQLObject;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.ibm.datatools.project.ui.node.INode;

public class LogicalDataModelLabelProvider extends LabelProvider {

	@Override
	public String getText(Object element) {
		if (element instanceof VirtualNode) {
			return ((VirtualNode) element).getName();
		}
		else if (element instanceof INode) {
			return ((INode) element).getName();
		}
		else if (element instanceof SQLObject) {
			return ((SQLObject) element).getName();
		}
		return element.toString();
	}
	
	@Override
	public Image getImage(Object element) {
		Image image = DataToolsUIServiceManager.INSTANCE.getImageService(element);
		return image;
	}
}
